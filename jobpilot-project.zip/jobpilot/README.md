# JobPilot AI (billing and access-control foundation)
Run: pip install -r requirements.txt; cp .env.example .env (fill values); uvicorn jobpilot.main:app --host 0.0.0.0 --port 8000
Test: python -m pytest -q
Render start command: uvicorn jobpilot.main:app --host 0.0.0.0 --port $PORT
Stripe webhook URL: <APP_BASE_URL>/webhooks/stripe. Events: checkout.session.completed, customer.subscription.created/updated/deleted, invoice.paid, invoice.payment_failed.
Plans and limits: edit plans.json (no code change). Render free disk is wiped on redeploy; use a persistent disk or Postgres before real customers.
