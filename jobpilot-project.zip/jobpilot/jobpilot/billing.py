import hashlib, hmac, json, os, sqlite3, time
import httpx
from .entitlements import PLANS

class NotConfigured(Exception): pass
class BadSignature(Exception): pass

class Provider:  # add PayPalProvider etc. by implementing these
    name = "base"
    def checkout_url(self, uid, email, plan): raise NotImplementedError
    def parse_webhook(self, raw, headers): raise NotImplementedError

class StripeProvider(Provider):
    name = "stripe"
    def plan_for_price(self, price_id):
        for k, p in PLANS.items():
            if p.get("price_env") and os.getenv(p["price_env"]) and os.getenv(p["price_env"]) == price_id: return k
    def checkout_url(self, uid, email, plan):
        key, base = os.getenv("STRIPE_SECRET_KEY"), os.getenv("APP_BASE_URL")
        price = os.getenv(PLANS.get(plan, {}).get("price_env", "_"), "")
        if not (key and base and price): raise NotConfigured("Stripe key, APP_BASE_URL or price ID is missing.")
        data = {"mode": "subscription", "line_items[0][price]": price, "line_items[0][quantity]": "1",
                "client_reference_id": uid, "customer_email": email, "metadata[user_id]": uid,
                "subscription_data[metadata][user_id]": uid,
                "success_url": base + "/billing/return", "cancel_url": base + "/pricing"}
        r = httpx.post("https://api.stripe.com/v1/checkout/sessions", data=data, auth=(key, ""), timeout=15)
        r.raise_for_status(); return r.json()["url"]
    def parse_webhook(self, raw, headers, tolerance=300, now=None):
        secret = os.getenv("STRIPE_WEBHOOK_SECRET")
        if not secret: raise NotConfigured("STRIPE_WEBHOOK_SECRET is missing.")
        items = [x.split("=", 1) for x in (headers.get("stripe-signature") or "").split(",") if "=" in x]
        ts = next((v for k, v in items if k == "t"), None); sigs = [v for k, v in items if k == "v1"]
        if not ts or not sigs: raise BadSignature("missing signature")
        exp = hmac.new(secret.encode(), ts.encode() + b"." + raw, hashlib.sha256).hexdigest()
        if not any(hmac.compare_digest(exp, s) for s in sigs): raise BadSignature("bad signature")
        if abs((now or time.time()) - int(ts)) > tolerance: raise BadSignature("stale timestamp")
        return json.loads(raw)

def get_provider():
    if os.getenv("BILLING_PROVIDER", "stripe") == "stripe": return StripeProvider()
    raise NotConfigured("Unknown BILLING_PROVIDER.")

def _uid(c, o):
    uid = (o.get("metadata") or {}).get("user_id") or o.get("client_reference_id")
    if uid: return uid
    for col, v in (("subscription_id", o.get("subscription") or o.get("id")), ("customer_id", o.get("customer"))):
        if v:
            r = c.execute(f"SELECT user_id FROM subscriptions WHERE {col}=?", (v,)).fetchone()
            if r: return r["user_id"]

def apply_event(c, ev, provider):
    """Idempotent. Returns 'processed' or 'duplicate'. Entitlements come only from here."""
    try: c.execute("INSERT INTO webhook_events(event_id,provider,type) VALUES(?,?,?)", (ev["id"], provider.name, ev["type"]))
    except sqlite3.IntegrityError: return "duplicate"
    t, o = ev["type"], ev["data"]["object"]; uid = _uid(c, o)
    if not uid: return "processed"
    c.execute("INSERT OR IGNORE INTO subscriptions(user_id) VALUES(?)", (uid,))
    if t == "checkout.session.completed":  # links IDs only; never unlocks a plan
        c.execute("UPDATE subscriptions SET provider=?,customer_id=?,subscription_id=? WHERE user_id=?", (provider.name, o.get("customer"), o.get("subscription"), uid))
    elif t in ("customer.subscription.created", "customer.subscription.updated"):
        item = ((o.get("items") or {}).get("data") or [{}])[0]
        plan = provider.plan_for_price((item.get("price") or {}).get("id")) or "free"
        ps = o.get("current_period_start") or item.get("current_period_start"); pe = o.get("current_period_end") or item.get("current_period_end")
        c.execute("UPDATE subscriptions SET plan=?,status=?,provider=?,customer_id=?,subscription_id=?,period_start=?,period_end=?,cancel_at_period_end=? WHERE user_id=?",
                  (plan, o.get("status"), provider.name, o.get("customer"), o.get("id"), ps, pe, 1 if o.get("cancel_at_period_end") else 0, uid))
    elif t == "customer.subscription.deleted":
        c.execute("UPDATE subscriptions SET plan='free',status='canceled' WHERE user_id=?", (uid,))
    elif t == "invoice.payment_failed":
        c.execute("UPDATE subscriptions SET status='past_due' WHERE user_id=? AND plan!='free'", (uid,))
    elif t == "invoice.paid":
        c.execute("INSERT OR IGNORE INTO payments(id,user_id,amount_cents,currency,status) VALUES(?,?,?,?,'paid')", (o["id"], uid, o.get("amount_paid"), o.get("currency")))
    return "processed"
