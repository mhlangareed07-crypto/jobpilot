import os, sqlite3
SCHEMA = """
CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,email TEXT UNIQUE NOT NULL,pw TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),expires_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS subscriptions(user_id TEXT PRIMARY KEY REFERENCES users(id),plan TEXT NOT NULL DEFAULT 'free',status TEXT NOT NULL DEFAULT 'none',provider TEXT,customer_id TEXT,subscription_id TEXT,period_start INTEGER,period_end INTEGER,cancel_at_period_end INTEGER DEFAULT 0);
CREATE INDEX IF NOT EXISTS ix_sub_cust ON subscriptions(customer_id);
CREATE INDEX IF NOT EXISTS ix_sub_sub ON subscriptions(subscription_id);
CREATE TABLE IF NOT EXISTS usage(user_id TEXT NOT NULL,kind TEXT NOT NULL,period_start INTEGER NOT NULL,used INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(user_id,kind,period_start));
CREATE TABLE IF NOT EXISTS usage_log(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT,kind TEXT,action TEXT,ref TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS webhook_events(event_id TEXT PRIMARY KEY,provider TEXT,type TEXT,received_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS saved_jobs(user_id TEXT NOT NULL,job_ref TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(user_id,job_ref));
CREATE TABLE IF NOT EXISTS payments(id TEXT PRIMARY KEY,user_id TEXT,amount_cents INTEGER,currency TEXT,status TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
"""
def conn():
    c = sqlite3.connect(os.getenv("DATABASE_PATH", "jobpilot.db"), isolation_level=None, timeout=10)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c
def init():
    c = conn(); c.executescript(SCHEMA); c.close()
