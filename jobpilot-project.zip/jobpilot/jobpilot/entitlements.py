import json, os, time, datetime
PLANS = json.load(open(os.path.join(os.path.dirname(__file__), "..", "plans.json")))
def _month_start(now):
    d = datetime.datetime.fromtimestamp(now, datetime.timezone.utc)
    return int(d.replace(day=1, hour=0, minute=0, second=0, microsecond=0).timestamp())
def effective(c, uid, now=None):
    """Plan and usage-period start derived ONLY from verified subscription rows."""
    now = now or int(time.time()); grace = int(os.getenv("GRACE_DAYS", "3")) * 86400
    s = c.execute("SELECT * FROM subscriptions WHERE user_id=?", (uid,)).fetchone()
    if s and s["plan"] in PLANS and s["plan"] != "free" and s["period_end"]:
        ok = s["status"] in ("active", "trialing") and s["period_end"] > now
        ok = ok or (s["status"] == "past_due" and s["period_end"] + grace > now)
        if ok: return s["plan"], s["period_start"] or _month_start(now), s
    return "free", _month_start(now), s
def remaining(c, uid, kind, now=None):
    plan, ps, _ = effective(c, uid, now)
    lim = PLANS[plan]["limits"][kind]
    r = c.execute("SELECT used FROM usage WHERE user_id=? AND kind=? AND period_start=?", (uid, kind, ps)).fetchone()
    return max(0, lim - (r["used"] if r else 0)), lim
def reserve(c, uid, kind, ref="", now=None):
    """Atomic: True only if allowance was available and is now deducted."""
    c.execute("BEGIN IMMEDIATE")
    try:
        plan, ps, _ = effective(c, uid, now); lim = PLANS[plan]["limits"][kind]
        c.execute("INSERT OR IGNORE INTO usage(user_id,kind,period_start,used) VALUES(?,?,?,0)", (uid, kind, ps))
        n = c.execute("UPDATE usage SET used=used+1 WHERE user_id=? AND kind=? AND period_start=? AND used<?", (uid, kind, ps, lim)).rowcount
        if n: c.execute("INSERT INTO usage_log(user_id,kind,action,ref) VALUES(?,?,'reserve',?)", (uid, kind, ref))
        c.execute("COMMIT"); return bool(n)
    except Exception:
        c.execute("ROLLBACK"); raise
def release(c, uid, kind, ref="", now=None):
    """Return the credit when the operation did not complete."""
    _, ps, _ = effective(c, uid, now)
    c.execute("UPDATE usage SET used=MAX(0,used-1) WHERE user_id=? AND kind=? AND period_start=?", (uid, kind, ps))
    c.execute("INSERT INTO usage_log(user_id,kind,action,ref) VALUES(?,?,'release',?)", (uid, kind, ref))
