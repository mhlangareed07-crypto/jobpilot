import hashlib, hmac, os, secrets, sqlite3, time, uuid, html
from fastapi import FastAPI, Form, Request, Response
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from . import db, entitlements as ent, billing
app = FastAPI(); db.init()
H = lambda s: html.escape(str(s))
def page(body, title="JobPilot AI"):
    return HTMLResponse(f'<!doctype html><meta name=viewport content="width=device-width,initial-scale=1"><title>{title}</title><body style="font:16px system-ui;max-width:640px;margin:auto;padding:16px">'
                        f'<nav><a href=/>Dashboard</a> · <a href=/pricing>Pricing</a></nav>{body}')
def hash_pw(p, salt=None):
    salt = salt or secrets.token_hex(8); return salt + "$" + hashlib.scrypt(p.encode(), salt=salt.encode(), n=2**14, r=8, p=1).hex()
def check_pw(p, stored): s = stored.split("$")[0]; return hmac.compare_digest(hash_pw(p, s), stored)
def user_of(req):
    t = req.cookies.get("sid"); c = db.conn()
    r = c.execute("SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires_at>?", (t, int(time.time()))).fetchone() if t else None
    c.close(); return r
def login_cookie(resp, uid):
    t = secrets.token_urlsafe(32); c = db.conn()
    c.execute("INSERT INTO sessions VALUES(?,?,?)", (t, uid, int(time.time()) + 14 * 86400)); c.close()
    resp.set_cookie("sid", t, httponly=True, samesite="lax", secure=os.getenv("COOKIE_SECURE", "1") == "1", max_age=14 * 86400)
@app.post("/signup")
def signup(email: str = Form(...), password: str = Form(...)):
    if "@" not in email or len(password) < 8: return page("<p role=alert>Enter a valid email and a password of 8+ characters.</p>")
    uid = str(uuid.uuid4()); c = db.conn()
    try: c.execute("INSERT INTO users(id,email,pw) VALUES(?,?,?)", (uid, email.lower().strip(), hash_pw(password)))
    except sqlite3.IntegrityError: return page("<p role=alert>That email is already registered.</p>")
    c.close(); r = RedirectResponse("/", 303); login_cookie(r, uid); return r
@app.post("/login")
def login(email: str = Form(...), password: str = Form(...)):
    c = db.conn(); u = c.execute("SELECT * FROM users WHERE email=?", (email.lower().strip(),)).fetchone(); c.close()
    if not u or not check_pw(password, u["pw"]): return page("<p role=alert>Wrong email or password.</p>")
    r = RedirectResponse("/", 303); login_cookie(r, u["id"]); return r
@app.get("/", response_class=HTMLResponse)
def dashboard(req: Request):
    u = user_of(req)
    if not u:
        f = '<form method=post action=%s><label>Email <input name=email type=email required></label> <label>Password <input name=password type=password minlength=8 required></label> <button>%s</button></form>'
        return page("<h1>JobPilot AI</h1>" + f % ("/login", "Log in") + f % ("/signup", "Sign up"))
    c = db.conn(); plan, ps, s = ent.effective(c, u["id"])
    kr, kl = ent.remaining(c, u["id"], "kit"); saved = c.execute("SELECT COUNT(*) n FROM saved_jobs WHERE user_id=?", (u["id"],)).fetchone()["n"]; c.close()
    end = time.strftime("%Y-%m-%d", time.gmtime(s["period_end"])) if s and s["period_end"] else "n/a"
    return page(f"<h1>Dashboard</h1><p>Plan: <b>{H(ent.PLANS[plan]['name'])}</b> · status: {H(s['status'] if s else 'none')} · renews/ends: {end}"
                f"{' · cancels at period end' if s and s['cancel_at_period_end'] else ''}</p><p>Application kits left: {kr} of {kl}</p><p>Saved jobs: {saved}</p>"
                "<p><small>Job search is not built yet (Phase 3). Kit generation needs an AI provider.</small></p>")
@app.get("/pricing", response_class=HTMLResponse)
def pricing():
    rows = "".join(f"<li><b>{H(p['name'])}</b> ${p['price_usd']}/month, billed monthly · {p['limits']['kit']} kits/month"
                   + (f"<form method=post action=/billing/checkout/{k}><button>Subscribe to {H(p['name'])}</button></form>" if k != "free" else "") + "</li>" for k, p in ent.PLANS.items())
    return page(f"<h1>Pricing</h1><ul>{rows}</ul><p><small>Cancel anytime in your account. A kit is generated documents, not a submitted application. Access starts only after payment is confirmed by the provider.</small></p>")
@app.post("/billing/checkout/{plan}")
def checkout(plan: str, req: Request):
    u = user_of(req)
    if not u: return RedirectResponse("/", 303)
    try: return RedirectResponse(billing.get_provider().checkout_url(u["id"], u["email"], plan), 303)
    except billing.NotConfigured as e: return page(f"<p role=alert>Payments are not configured: {H(e)}</p>")
@app.get("/billing/return", response_class=HTMLResponse)
def ret(): return page("<p>Thanks. Your plan activates once the payment provider confirms it. Refresh the dashboard in a moment.</p>")
@app.post("/webhooks/stripe")
async def stripe_hook(req: Request):
    p = billing.get_provider(); raw = await req.body()
    try: ev = p.parse_webhook(raw, req.headers)
    except billing.BadSignature: return JSONResponse({"error": "bad signature"}, 400)
    except billing.NotConfigured: return JSONResponse({"error": "not configured"}, 503)
    c = db.conn(); r = billing.apply_event(c, ev, p); c.close(); return {"result": r}
@app.post("/api/kits")
def make_kit(req: Request, job_ref: str = Form(...)):
    u = user_of(req)
    if not u: return JSONResponse({"error": "login required"}, 401)
    c = db.conn()
    if not ent.reserve(c, u["id"], "kit", job_ref): c.close(); return JSONResponse({"error": "No application-kit allowance left on your plan."}, 402)
    ent.release(c, u["id"], "kit", job_ref); c.close()  # no AI provider adapter yet: refund the credit
    return JSONResponse({"error": "AI provider not configured; no credit used."}, 503)
