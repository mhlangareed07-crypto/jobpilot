import hashlib, hmac, json, os, tempfile, time, threading
os.environ["DATABASE_PATH"] = tempfile.mktemp(suffix=".db"); os.environ.update(STRIPE_WEBHOOK_SECRET="whsec_test", STRIPE_PRICE_PRO="price_pro", STRIPE_PRICE_POWER="price_power", COOKIE_SECURE="0")
from fastapi.testclient import TestClient
from jobpilot.main import app
from jobpilot import db, entitlements as ent
cl = TestClient(app); SEC = "whsec_test"
def sign(body, ts=None):
    ts = str(ts or int(time.time())); return {"stripe-signature": f"t={ts},v1=" + hmac.new(SEC.encode(), ts.encode() + b"." + body, hashlib.sha256).hexdigest()}
def signup(email):
    c = TestClient(app); c.post("/signup", data={"email": email, "password": "password123"}, follow_redirects=False); return c
def uid(email):
    c = db.conn(); r = c.execute("SELECT id FROM users WHERE email=?", (email,)).fetchone()["id"]; c.close(); return r
def sub_event(eid, u, status="active", price="price_pro", end=None):
    o = {"id": "sub_" + u[:6], "customer": "cus_" + u[:6], "status": status, "metadata": {"user_id": u}, "current_period_start": int(time.time()), "current_period_end": end or int(time.time()) + 2592000, "items": {"data": [{"price": {"id": price}}]}}
    return json.dumps({"id": eid, "type": "customer.subscription.updated", "data": {"object": o}}).encode()
def post(body, **kw): return cl.post("/webhooks/stripe", content=body, headers=sign(body, **kw))
def test_bad_and_stale_signature_rejected():
    b = b"{}"
    assert cl.post("/webhooks/stripe", content=b, headers={"stripe-signature": "t=1,v1=abc"}).status_code == 400
    assert post(b, ts=int(time.time()) - 9999).status_code == 400
def test_redirect_does_not_unlock_and_webhook_does():
    signup("a@x.com"); u = uid("a@x.com"); c = db.conn()
    cl.get("/billing/return"); assert ent.effective(c, u)[0] == "free"
    assert post(sub_event("evt_a1", u)).json()["result"] == "processed"
    assert ent.effective(c, u)[0] == "pro"; assert ent.remaining(c, u, "kit") == (30, 30)
def test_duplicate_webhook_is_idempotent():
    signup("b@x.com"); u = uid("b@x.com"); b = sub_event("evt_b1", u)
    assert post(b).json()["result"] == "processed"; assert post(b).json()["result"] == "duplicate"
def test_free_user_cannot_use_kits_and_failed_payment_grace():
    signup("c@x.com"); u = uid("c@x.com"); c = db.conn()
    assert ent.reserve(c, u, "kit") is False
    post(sub_event("evt_c1", u, status="past_due", end=int(time.time()) - 3600)); assert ent.effective(c, u)[0] == "pro"  # inside grace
    post(sub_event("evt_c2", u, status="past_due", end=int(time.time()) - 9 * 86400)); assert ent.effective(c, u)[0] == "free"
def test_concurrent_reserve_never_overspends():
    signup("d@x.com"); u = uid("d@x.com"); post(sub_event("evt_d1", u)); res = []
    def go():
        c = db.conn(); res.append(ent.reserve(c, u, "kit")); c.close()
    ts = [threading.Thread(target=go) for _ in range(45)]; [t.start() for t in ts]; [t.join() for t in ts]
    assert sum(res) == 30
def test_cancel_and_api_requires_auth():
    signup("e@x.com"); u = uid("e@x.com"); post(sub_event("evt_e1", u))
    body = json.dumps({"id": "evt_e2", "type": "customer.subscription.deleted", "data": {"object": {"id": "sub_" + u[:6], "metadata": {"user_id": u}}}}).encode(); post(body)
    c = db.conn(); assert ent.effective(c, u)[0] == "free"
    assert TestClient(app).post("/api/kits", data={"job_ref": "x"}).status_code == 401
def test_kit_endpoint_refunds_credit_without_ai():
    c0 = signup("f@x.com"); u = uid("f@x.com"); post(sub_event("evt_f1", u)); r = c0.post("/api/kits", data={"job_ref": "j"})
    assert r.status_code == 503; c = db.conn(); assert ent.remaining(c, u, "kit")[0] == 30
